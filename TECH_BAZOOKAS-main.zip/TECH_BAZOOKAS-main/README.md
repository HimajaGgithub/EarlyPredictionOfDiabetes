# TECH_BAZOOKAS
Title: Early detection of Diabetes using Machine Learning algorithm

Many of us might be wondering that the project might already exist. But this is different!!

Process:
1. Initially the user will enter into our website and sign up with our website.
2. The user must fill in all the personal details related to them which includes Name, age, occupation and  gender.
3. Later we will ask questions related to the main symptoms that will contribute to the Diabetes.
4. The user will be able to enter three options , either "yes" , "no" or "Maybe".
5. Our model will be helpful to Learn about them and their current status, which will help us to identify at which age they will be prone to the DIABETES.
6. Further we will get the percentage of diabetes that has been affected to them.
7. Based on this prediction, we will give a Diabetes Reversal day to day schedule and food habits that they have to folow.
8. This will make the users can get to know if they might be prone to diabetes , if yes at which age, at an early stage based on their day to day lifetstyle.

Result:
1. We will classify the users as Diabetic patient and non diabetic patient, along with classifying them into Type 2 or Type 3, if they are prone to diabetes.
2. For non diabetic patients, we will suggest a Diabetes reversal diet plan, if they are prone to get diabetes in future.
3. For highly diabetic patient =, we will suggest them to consukt the doctor.
